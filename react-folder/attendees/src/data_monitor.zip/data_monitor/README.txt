# Data-Monitor

PLEASE FOLLOW INSTRUCTIONS BEFORE USING DATA MONITOR

- Download the latest version of Python via [(https://www.python.org/downloads/)]
- This is a CLI application, please open your terminal
- In your terminal run the following command:

    - cd data_monitor #Go to the directory of the data monitor folder first

    - pip install -r requirements.txt

    - python data_mining.py #This will run the Data Monitoring CLI Application