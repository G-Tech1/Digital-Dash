# Data-Monitor

PLEASE FOLLOW INSTRUCTIONS BEFORE USING DATA MONITOR

- This is a CLI application, please open your terminal
- Download the latest version of Python via [(https://www.python.org/downloads/)]
- In your terminal run the following command:
    - pip install -r requirements.txt
    - python data_mining.py #This will run the Data Monitoring CLI Application
    
